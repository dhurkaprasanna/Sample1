import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/category.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  public products: any;
  public name:string;
  public category:string;
  public tag:string;
  public tag2:string;
  public tag3:string;
  public open1:boolean;
  public open2:boolean;
  public open3:boolean;
  constructor(private cat:CategoryService) { }

  ngOnInit(): void {
    this.tag="Add";
    this.tag2="Remove";
    this.tag3="Change";
    this.invt1();
    this.open1=false;
    this.invt2();
    this.open2=false;
    this.invt3();
    this.open3=false;
  }



  public invt1() {
  this.cat.Products().subscribe((data) => {
    this.products = data;
  });
  }
  public clicked1(){
    this.open1=!this.open1;
   if(this.tag==="Add"){
    this.tag3="Change";
    this.tag2="Remove";
    this.open2=false;
    this.open3=false;
     this.tag="Exit";
   }
   else{
     this.tag="Add";
   }
   return this.open1;
  }

  public invt2() {
    this.cat.Products().subscribe((data) => {
      this.products = data;
    });
    }
    public clicked2(){
      this.open2=!this.open2;
     if(this.tag2==="Remove"){
       this.tag="Add";
       this.tag3="Change"
       this.open1=false;
       this.open3=false;
       this.tag2="Exit";
     }
     else{
       this.tag2="Remove";
     }
     return this.open2;
    }

    public invt3() {
      this.cat.Products().subscribe((data) => {
        this.products = data;
      });
      }
      public clicked3(){
        this.open3=!this.open3;
       if(this.tag3==="Change"){
         this.tag="Add";
         this.tag2="Remove";
         this.open1=false;
         this.open2=false;
         this.tag3="Exit";
       }
       else{
         this.tag3="Change";
       }
       return this.open3;
      }
 
  public post(){
    // this.cat.PostProducts("Dove","Groceries").subscribe((data)=>{
    //   console.log(data)
    // });
  }
}

