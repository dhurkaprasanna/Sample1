import { Chart } from 'chart.js';
import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/category.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})

export class HomePageComponent implements OnInit {
  public count:number;
  public pcount: any;
  public products: any;

  constructor(private cat:CategoryService) { }

public canvas:any;
public ctx:any;
public canva:any;
public ct:any;

  ngOnInit(): void {
    this.invt();


    this.canvas = document.getElementById("myChart");
    this.ctx = this.canvas.getContext("2d");
var myChart = new Chart(this.ctx, {
    type: 'pie',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
      
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});

this.canva = document.getElementById("stackedBar");
    this.ct= this.canva.getContext("2d");
var stackedBar = new Chart(this.ct, {
  type: 'bar',
  data: {
    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    datasets: [{
        label: '# of Votes',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: [
            "red",
            "green",
            "orange",
            "blue",
            "violet",
            "yellow"
        ],
        borderColor: [
            'rgba(255, 99, 132, 1)',
            'rgba(54, 162, 235, 1)',
            'rgba(255, 206, 86, 1)',
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1
    },{
    label: '# of Votes',
        data: [12, 19, 3, 5, 2, 3],
        backgroundColor: [
          "green",
            "orange",
            "blue",
            "violet",
            "yellow",
            "red"
      ],
      borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
      ],
    }
  ]
},
  options: {
      scales: {
          xAxes: [{
              stacked: true
          }],
          yAxes: [{
              stacked: true
          }]
      }
  }
});
     
        }
  public invt() {

    this.cat.CategoryCount().subscribe((data) => {
      this.count = data.count;
    });
    this.cat.ProductCount().subscribe((data) => {
      this.pcount = data.count;
    });
   
  }



}

