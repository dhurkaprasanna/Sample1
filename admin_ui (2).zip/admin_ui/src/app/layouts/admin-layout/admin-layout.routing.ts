import { CategoryComponent } from './../../pages/category/category.component';
import { ShopComponent } from './../../pages/shop/shop.component';
import { ProductComponent } from './../../pages/product/product.component';
import { HomePageComponent } from './../../pages/home-page/home-page.component';
import { Routes } from "@angular/router";

import { DashboardComponent } from "../../pages/dashboard/dashboard.component";

export const AdminLayoutRoutes: Routes = [
  { path: "dashboard", component: DashboardComponent },
  {path:"home-page", component:HomePageComponent},
  {path:"product", component:ProductComponent},
  {path:"shop", component:ShopComponent},
  {path:"category", component:CategoryComponent},
];
