import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private API_URL=environment.apiUrl;

  constructor(private http: HttpClient) { }

  public allCategory(): Observable<any> {
    var url = this.API_URL + '/products';
    return this.http.get(url);
  }

  public CategoryCount(): Observable<any> {
    var url = this.API_URL + '/categories/count';
    return this.http.get(url);
  }

  public ProductCount(): Observable<any> {
    var url = this.API_URL + '/products/count';
    return this.http.get(url);
  }

  public Products(): Observable<any> {
    var url = this.API_URL + '/products';
    return this.http.get(url)
  }
  public PostProducts(name,category):Observable<any>{
    var url = this.API_URL + '/products';
    return this.http.post(url,{
      name:name,
      category:category
    })
  }
  
}
